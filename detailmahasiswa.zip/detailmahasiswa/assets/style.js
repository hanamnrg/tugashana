import { StyleSheet } from 'react-native';

const gaya = StyleSheet.create({
  cardutama: {
    margin: 5,
    shadowColor: '#470000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
  },
  cardview: {
    flexDirection: 'row',
    padding: 6,
  },
  teks: {
    fontSize: 14,
  },
  foto:{
    width:50,
    height:50,
    borderRadius:50/2
  }
});

export { gaya };
