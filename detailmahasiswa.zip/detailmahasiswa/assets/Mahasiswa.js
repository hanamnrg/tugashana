const mahasiswa = [
  {
    id:'1',
    nim: '1234',
    nama: 'adi',
    email: 'adi@udb.ac.id',
    hp: '0857675265362',
    foto: 'https://i.postimg.cc/zBmNsNsm/icon1.png',
  },
  {
    id:'1',
    nim: '546456',
    nama: 'rudi',
    email: 'rudi@udb.ac.id',
    hp: '0882564484864',
    foto: 'https://i.postimg.cc/FKkmCzng/icon3.png',
  },
];
export default mahasiswa;
