import React, { useState } from 'react';
import { Text, View, Image, FlatList } from 'react-native';
import { Card } from 'react-native-paper';
import Mahasiswa from '../assets/Mahasiswa';
import { gaya } from '../assets/style';

const Home = ({navigation}) => {
  const [data, setdata] = useState(Mahasiswa);

  const listmahasiswa = ({ item }) => {
    return (
      <Card style={gaya.cardutama}
        onPress={()=>navigation.navigate('Detail', { mahasiswa: item })}>
          <View style={gaya.cardview}>
            <Image style={gaya.foto} source={{ uri: item.foto }} />
            <View style={{marginLeft:12}}>
              <Text style={gaya.teks}>{item.nama}</Text>
              <Text style={gaya.teks}>{item.hp}</Text>
            </View>
          </View>
       
      </Card>
    );
  };

  return (
    <View>
      <FlatList
        data={data}
        renderItem={listmahasiswa}
        keyExtractor={(item) => item.id}
      />
    </View>
  );
};

export default Home;