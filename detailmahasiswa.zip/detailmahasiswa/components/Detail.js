import React, { useState } from 'react';
import { Text, View, Image, Button, Linking } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Title, Card } from 'react-native-paper';
import { MaterialIcons, Entypo } from '@expo/vector-icons';

const Detail = ({ route,navigation}) => {
  const { mahasiswa } = route.params;

  return (
    <View>
      <LinearGradient colors={["#0033ff","#6bc1ff"]} style={{height:"20%"}}/>

      <View style={{alignItems:"center"}}>
        <Image source={{ uri: mahasiswa.foto }} style={{width:120,height:120,borderRadius:120/2,marginTop:-50}}/>
      </View>

      <View style={{alignItems:'center',margin:15}}>
        <Title>Nama : {mahasiswa.nama}</Title>
        <Text style={{fontsize:14}}>NIM : {mahasiswa.nim}</Text>
      </View>

      <Card style={{margin:3}}
        onPress={() => {
          Linking.openURL('mailto:${mahasiswa.email}');
        }}>
        <View style={{flexDirection:'row',padding:8}}>
          <MaterialIcons name="email" size={32} color="#006aff"/>
          <Text>{mahasiswa.email}</Text>
        </View>
      </Card>

      <Card style={{margin:3}}
        onPress={() => {
          Linking.openURL('tel:${mahasiswa.hp}');
        }}>
        <View style={{flexDirection:'row',padding:8}}>
          <Entypo name="phone" size={32} color="#006aff"/>
          <Text>{mahasiswa.hp}</Text>
        </View>
      </Card>

    </View>
  );
};

export default Detail;
